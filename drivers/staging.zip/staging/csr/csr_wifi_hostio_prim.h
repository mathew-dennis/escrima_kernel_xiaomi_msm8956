/*****************************************************************************

            (c) Cambridge Silicon Radio Limited 2011
            All rights reserved and confidential information of CSR

            Refer to LICENSE.txt included with this source for details
            on the license terms.

*****************************************************************************/


#ifndef CSR_WIFI_HOSTIO_H
#define CSR_WIFI_HOSTIO_H

#define CSR_WIFI_HOSTIO_PRIM 0x0453

#endif /* CSR_WIFI_HOSTIO_H */

