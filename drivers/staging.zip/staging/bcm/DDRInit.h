#ifndef _DDR_INIT_H_
#define _DDR_INIT_H_



int ddr_init(struct bcm_mini_adapter *psAdapter);
int download_ddr_settings(struct bcm_mini_adapter *psAdapter);

#endif
