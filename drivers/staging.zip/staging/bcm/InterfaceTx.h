#ifndef _INTERFACE_TX_H
#define _INTERFACE_TX_H

INT InterfaceTransmitPacket(PVOID arg, PVOID data, UINT len);

#endif

