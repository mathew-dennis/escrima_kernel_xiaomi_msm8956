#ifndef _INTERFACE_RX_H
#define _INTERFACE_RX_H

BOOLEAN InterfaceRx(struct bcm_interface_adapter *Adapter);

#endif

